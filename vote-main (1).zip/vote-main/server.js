import express from "express";
import cors from "cors";

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static("."));

let votes = {
  Boy1: 0, Boy2: 0, Boy3: 0, Boy4: 0,
  Girl1: 0, Girl2: 0, Girl3: 0, Girl4: 0
};
let usedEmails = new Set();

app.post("/check-email", (req, res) => {
  const { email } = req.body;
  res.json({ exists: usedEmails.has(email) });
});

app.post("/submit-vote", (req, res) => {
  const { email, votes: v } = req.body;
  if (usedEmails.has(email)) {
    return res.json({ success: false, message: "Already voted" });
  }
  v.forEach(c => votes[c]++);
  usedEmails.add(email);
  res.json({ success: true });
});

app.get("/results", (req, res) => res.json(votes));

app.post("/clear", (req, res) => {
  votes = {
    Boy1: 0, Boy2: 0, Boy3: 0, Boy4: 0,
    Girl1: 0, Girl2: 0, Girl3: 0, Girl4: 0
  };
  usedEmails.clear();
  res.json({ success: true });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`✅ Server running on ${PORT}`));
